
def backstr (strin):

    strin = strin.strip()
    lis = strin.split(" ")
    wr = ""

    for word in lis:
        for index,letter in enumerate(word):
            wr += word[len(word)-1-index]
        wr += " "
      
    return wr
            
            
StrInput = input("Enter your request: ")
re = backstr(StrInput)
print(re)
